export interface MusicData {
  title: string;
  artist: string;
  cover: string;
  audio: string;
}
