export interface UserData {
  name: string;
  avatar: string;
  password: string;
}
