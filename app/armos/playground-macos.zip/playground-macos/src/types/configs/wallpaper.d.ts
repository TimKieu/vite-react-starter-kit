export interface WallpaperData {
  day: string;
  night: string;
}
