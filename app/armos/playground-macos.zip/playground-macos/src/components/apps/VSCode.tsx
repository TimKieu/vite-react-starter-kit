export default function VSCode() {
  return (
    <iframe
      className="h-full w-full bg-vscode"
      src="https://github1s.com/Renovamen/playground-macos/blob/main/README.md"
      title="VSCode"
    />
  );
}
